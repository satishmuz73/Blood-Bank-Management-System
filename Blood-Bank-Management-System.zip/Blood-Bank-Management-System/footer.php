<?php 
$con->close();
echo "</div></div></body></html>";
?>